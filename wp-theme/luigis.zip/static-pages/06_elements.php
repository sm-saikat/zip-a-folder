

                  <section class="bg-8 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>THE BEST IN TOWN</b></h5>
                                <h3 class="mt-30 mb-15">Our Blog</h3>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section><section class="story-area left-text center-sm-text">
        <div class="container">
                <div class="row">
                        <div class="col-md-12">
                                <div class="mb-20">
                                         <h6 class="dplay-inl-block m-10"><a href="#" class="btn-primaryc plr-25"><b>SEND MESSAGE</b></a></h6>
                                         <h6 class="dplay-inl-block m-10"><a href="#" class="btn-fill-primary plr-25"><b>SEND MESSAGE</b></a></h6>
                                         <h6 class="dplay-inl-block m-10"><a href="#" class="btn-primaryc secondary plr-25"><b>SEND MESSAGE</b></a></h6>
                                         <h6 class=" dplay-inl-block m-10"><a href="#" class="btn-fill-primary secondary plr-25"><b>SEND MESSAGE</b></a></h6>
                                </div><!-- mb-20-->
                        </div><!-- col-md-6-->
                </div><!-- row -->
        </div><!-- container -->
</section><section class="story-area left-text center-sm-text pt-0">
        <div class="container">
                <h5 class="font-30 mb-70 mb-sm-40 left-text"><b>Accordians & Tabs</b></h5>
                <div class="row">
                        <div class="col-md-12 col-lg-6">
                                <div class="panel mb-30">
                                        <div class="panel-area mb-30">
                                                <p class="panel-title active"><a class="dplay-block" href="#"> Nullah roncha nibih nibih, vel
                                                        scrurty mouris<i class="icon minus ion-minus"></i><i class="icon plus ion-plus"></i></a></p>
                                                <p class="panel-desc">reflects the gradient pattern from start-to-end then end-to-start then start-to-end, continuously until the region is filled.</p>
                                        </div><!-- panel-area -->

                                        <div class="panel-area mb-30">
                                                <p class="panel-title"><a class="dplay-block" href="#">Nullah roncha nibih nibih, vel scrurty mouris
                                                        <i class="icon minus ion-minus"></i><i class="icon plus ion-plus"></i></a></p>
                                                <p class="panel-desc">reflects the gradient pattern from start-to-end then end-to-start then start-to-end, continuously until the region is filled.</p>
                                        </div><!-- panel-area -->

                                        <div class="panel-area mb-30">
                                                <p class="panel-title"><a class="dplay-block" href="#">Nullah roncha nibih nibih, vel scrurty mouris
                                                        <i class="icon minus ion-minus"></i><i class="icon plus ion-plus"></i></a></p>
                                                <p class="panel-desc">reflects the gradient pattern from start-to-end then end-to-start then start-to-end, continuously until the region is filled.</p>
                                        </div><!-- panel-area -->
                                </div><!-- panel -->
                        </div><!-- col-sm-6-->

                        <div class="col-md-12 col-lg-6">
                                <div class="selecton tab-style-1 mb-10">
                                        <div class="row">
                                                <div class="col-sm-4 plr-5 pl-15 mb-15"><a href="#" class=" ptb-20 dplay-block active" data-select="sec-1"><b>Cras hendrerit imper</b></a></div>
                                                <div class="col-sm-4 plr-5 mb-15"><a href="#" class=" ptb-20 dplay-block" data-select="sec-2"><b>Mauris et odio conv</b></a></div>
                                                <div class="col-sm-4 plr-5 pr-15 mb-15"> <a href="#" class=" ptb-20 dplay-block" data-select="sec-3"><b>Aenean a ante eleif</b></a></div>
                                        </div><!--row-->
                                </div><!--tab-style-1-->

                                <div class="sec-1 food-menu">
                                        <div class="row">
                                                <div class="col-sm-6"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-1-120x120.jpg" alt="Menu Image"></div>
                                                <div class="col-sm-6">
                                                        <p class="mt-15">Cras hendrerit imperdiet ligula. Mauris et odio convallis, consequat ex eget, varius metus.
                                                                Aenean a ante eleifend, elementum diam eu, tempus velit. In sit amet justo eu sem posuere eleifend sit amet ut lectus.  </p>
                                                </div><!-- col-sm-6-->
                                        </div><!--row-->
                                </div><!-- food-menu -->

                                <div class="sec-2 food-menu">
                                        <div class="row">
                                                <div class="col-sm-6"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-2-120x120.jpg" alt="Menu Image"></div>
                                                <div class="col-sm-6">
                                                        <p class="mt-15">Cras hendrerit imperdiet ligula. Mauris et odio convallis, consequat ex eget, varius metus.
                                                                Aenean a ante eleifend, elementum diam eu, tempus velit. In sit amet justo eu sem posuere eleifend sit amet ut lectus.  </p>
                                                </div><!-- col-sm-6-->
                                        </div><!--row-->
                                </div><!-- food-menu -->

                                <div class="sec-3 food-menu">
                                        <div class="row">
                                                <div class="col-sm-6"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-3-120x120.jpg" alt="Menu Image"></div>
                                                <div class="col-sm-6">
                                                        <p class="mt-15">Cras hendrerit imperdiet ligula. Mauris et odio convallis, consequat ex eget, varius metus.
                                                                Aenean a ante eleifend, elementum diam eu, tempus velit. In sit amet justo eu sem posuere eleifend sit amet ut lectus.  </p>
                                                </div><!-- col-sm-6-->
                                        </div><!--row-->
                                </div><!-- food-menu -->
                        </div><!--col-sm-6-->

                </div><!-- row -->
        </div><!-- container -->
</section><section class="pt-0">
        <div class="container">
                <h5 class="font-30 mb-70 mb-sm-40 left-text"><b>Loaders</b></h5>

                <div class="row font-beyond">
                        <div class="col-sm-6 col-md-6 col-lg-3">
                                <div class="radial-prog-area">
                                        <div class="radial-progress" data-prog-percent=".97"><div></div><h5 class=" progress-title">Pizza</h5></div>
                                </div><!-- radial-prog-area-->
                        </div><!-- col-sm-6-->

                        <div class="col-sm-6 col-md-6 col-lg-3">
                                <div class="radial-prog-area">
                                        <div class="radial-progress" data-prog-percent=".78"><div></div><h5 class=" progress-title">Pasta</h5></div>
                                </div><!-- radial-prog-area-->
                        </div><!-- col-sm-6-->

                        <div class="col-sm-6 col-md-6 col-lg-3">
                                <div class="radial-prog-area">
                                        <div class="radial-progress" data-prog-percent=".67"><div></div><h5 class=" progress-title">Love</h5></div>
                                </div><!-- radial-prog-area-->
                        </div><!-- col-sm-6-->

                        <div class="col-sm-6 col-md-6 col-lg-3">
                                <div class="radial-prog-area">
                                        <div class="radial-progress" data-prog-percent=".97"><div></div><h5 class=" progress-title">Fresh</h5></div>
                                </div><!-- radial-prog-area-->
                        </div><!-- col-sm-6-->

                </div><!-- row-->
        </div><!-- container-->
</section><section class="counter-section center-text pt-0" id="counter">
        <div class="container">
                <h5 class="font-30 mb-70 mb-sm-40 left-text"><b>Milestones</b></h5>
                <div class="row">
                        <div class="col-sm-6 col-md-3">
                                <div class="mb-30 ">
                                        <i class="mlr-auto mb-30  icon-gradient icon-pizza"></i>
                                        <h2><b><span class="counter-value" data-duration="400" data-count="574">0</span></b></h2>
                                        <h5 class="semi-black"><b>Pizza per day</b></h5>
                                </div><!-- margin-b-30 -->
                        </div><!-- col-md-3-->

                        <div class="col-sm-6 col-md-3">
                                <div class="mb-30">
                                        <i class="mlr-auto mb-30 icon-gradient icon-sea-food"></i>
                                        <h2><b><span class="counter-value" data-duration="1400" data-count="14">0</span></b></h2>
                                        <h5 class="semi-black"><b>Sea Food Dshes</b></h5>
                                </div><!-- margin-b-30 -->
                        </div><!-- col-md-3-->

                        <div class="col-sm-6 col-md-3">
                                <div class="mb-30">
                                        <i class="mlr-auto mb-30 icon-gradient icon-pasta"></i>
                                        <h2><b><span class="counter-value" data-duration="300" data-count="3">0</span></b></h2>
                                        <h5 class="semi-black"><b>Pasta Chefs</b></h5>
                                </div><!-- margin-b-30 -->
                        </div><!-- col-md-3-->

                        <div class="col-sm-6 col-md-3">
                                <div class="mb-30">
                                        <i class="mlr-auto mb-30 icon-gradient icon-salad"></i>
                                        <h2><b><span class="counter-value" data-duration="1000" data-count="52">0</span></b></h2>
                                        <h5 class="semi-black"><b>Salads per day</b></h5>
                                </div><!-- margin-b-30 -->
                        </div><!-- col-md-3-->

                </div><!-- row-->
        </div><!-- container-->
</section><section class="pt-0">
        <div class="container">
                <h5 class="font-30 mb-70 mb-sm-40"><b>Icon Boxes</b></h5>

                <div class="row">
                        <div class="col-sm-12 col-md-6 col-lg-4">
                                <h4 class="pos-relative mb-20 pt-20"><i class="abs-bl icon-box icon-pizza"></i><b class="pl-60">Italian pizza</b></h4>
                                <p class="mb-30">Vivamus sed ligula imperdiet, feugiat magna vitae, blandit ex. Vestibulum id dapibus dolor, ac cursus nulla. Sed laoreet ut felis vel blandit. </p>
                        </div><!-- col-md-4-->

                        <div class="col-sm-12 col-md-6 col-lg-4">
                                <h4 class="pos-relative mb-20 pt-20"><i class="abs-bl icon-box icon-ingradient"></i><b class="pl-60">Best ingredients</b></h4>
                                <p class="mb-30">Vivamus sed ligula imperdiet, feugiat magna vitae, blandit ex. Vestibulum id dapibus dolor, ac cursus nulla. Sed laoreet ut felis vel blandit. </p>
                        </div><!-- col-md-4-->

                        <div class="col-sm-12 col-md-6 col-lg-4">
                                <h4 class="pos-relative mb-20 pt-20"><i class="abs-bl icon-box icon-cshef"></i><b class="pl-60">Top Chefs</b></h4>
                                <p class="mb-30">Vivamus sed ligula imperdiet, feugiat magna vitae, blandit ex. Vestibulum id dapibus dolor, ac cursus nulla. Sed laoreet ut felis vel blandit. </p>
                        </div><!-- col-md-4-->
                </div><!-- row-->
        </div><!-- container-->
</section>
              
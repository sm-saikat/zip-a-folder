

                  <section class="bg-5 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>THE BEST IN TOWN</b></h5>
                                <h2 class="mt-30 mb-15">Menu</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section><section class="story-area left-text center-sm-text">
        <div class="container">
                <div class="heading"><h3>Choose from Pizza</h3></div>
                <div class="row">
                        <div class="col-lg-3 col-md-4  col-sm-6 ">
                                <div class="center-text mb-30">
                                        <div class="ïmg-200x mlr-auto pos-relative">
                                                <h6 class="ribbon-cont color-white"><div class="ribbon primary"></div><b>OFFER</b></h6>
                                                <img src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/seller-2-200x200.png" alt="">
                                        </div>
                                        <h5 class="mt-20">Pizza Margherita</h5>
                                        <h4 class="mt-5 color-primary"><b>$11.90</b></h4>
                                </div><!--text-center-->
                        </div><!-- col-md-3 -->

                        <div class="col-lg-3 col-md-4  col-sm-6 ">
                                <div class="center-text mb-30">
                                        <div class="ïmg-200x mlr-auto pos-relative"><img src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/seller-2-200x200.png" alt=""></div>
                                        <h5 class="mt-20">Pizza Margherita</h5>
                                        <h4 class="mt-5 color-primary"><b>$11.90</b></h4>
                                </div><!--text-center-->
                        </div><!-- col-md-3 -->

                        <div class="col-lg-3 col-md-4  col-sm-6 ">
                                <div class="center-text mb-30">
                                        <div class="ïmg-200x mlr-auto pos-relative"><img src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/seller-2-200x200.png" alt=""></div>
                                        <h5 class="mt-20">Pizza Margherita</h5>
                                        <h4 class="mt-5 color-primary"><b>$11.90</b></h4>
                                </div><!--text-center-->
                        </div><!-- col-md-3 -->

                        <div class="col-lg-3 col-md-4  col-sm-6 ">
                                <div class="center-text mb-30">
                                        <div class="ïmg-200x mlr-auto pos-relative">
                                                <h6 class="ribbon-cont color-white"><div class="ribbon secondary"></div><b>SPECIALITY</b></h6>
                                                <img src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/seller-2-200x200.png" alt="">
                                        </div>
                                        <h5 class="mt-20">Pizza Margherita</h5>
                                        <h4 class="mt-5 color-primary"><b>$11.90</b></h4>
                                </div><!--text-center-->
                        </div><!-- col-md-3 -->
                </div><!-- row-->
        </div><!-- container -->
</section><section class="bg-lite-blue">
        <div class="container">
                <div class="row">

                        <div class="col-md-6">
                                <div class="sided-90x mb-30 ">
                                        <div class="s-left"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-1-120x120.jpg" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h5 class="mb-10"><b>Pizza Margherita</b><b class="color-primary float-right">$12.00</b></h5>
                                                <p class="pr-70">Maecenas fermentum tortor id fringilla molestie. In hac habitasse platea dictumst. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->

                        <div class="col-md-6">
                                <div class="sided-90x mb-30 ">
                                        <div class="s-left"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-2-120x120.jpg" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h5 class="mb-10"><b>Italian pasta</b><b class="color-primary float-right">$20.00</b></h5>
                                                <p class="pr-70">Proin dictum viverra varius. Etiam vulputate libero dui, at pretium elit elementum quis. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->

                        <div class="col-md-6">
                                <div class="sided-90x mb-30 ">
                                        <div class="s-left"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-3-120x120.jpg" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h5 class="mb-10"><b>Pizza Prosciuto</b><b class="color-primary float-right">$12.00</b></h5>
                                                <p class="pr-70">Maecenas fermentum tortor id fringilla molestie. In hac habitasse platea dictumst. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->

                        <div class="col-md-6">
                                <div class="sided-90x mb-30">
                                        <div class="s-left"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-4-120x120.jpg" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h5 class="mb-10"><b>Broschettas</b><b class="color-primary float-right">$6.00</b></h5>
                                                <p class="pr-70">Proin dictum viverra varius. Etiam vulputate libero dui, at pretium elit elementum quis. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->

                        <div class="col-md-6">
                                <div class="sided-90x mb-30">
                                        <div class="s-left"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-5-120x120.jpg" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h5 class="mb-10"><b>Pizza Margherita</b><b class="color-primary float-right">$12.00</b></h5>
                                                <p class="pr-70">Maecenas fermentum tortor id fringilla molestie. In hac habitasse platea dictumst. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->

                        <div class="col-md-6">
                                <div class="sided-90x mb-30 ">
                                        <div class="s-left"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-6-120x120.jpg" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h5 class="mb-10"><b>Italian pasta</b><b class="color-primary float-right">$20.00</b></h5>
                                                <p class="pr-70">Proin dictum viverra varius. Etiam vulputate libero dui, at pretium elit elementum quis. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->

                        <div class="col-md-6">
                                <div class="sided-90x mb-30">
                                        <div class="s-left"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-7-120x120.jpg" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h5 class="mb-10"><b>Pizza Prosciuto</b><b class="color-primary float-right">$12.00</b></h5>
                                                <p class="pr-70">Maecenas fermentum tortor id fringilla  molestie. In hac habitasse platea dictumst. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->

                        <div class="col-md-6">
                                <div class="sided-90x mb-30 ">
                                        <div class="s-left"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-8-120x120.jpg" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h5 class="mb-10"><b>Broschettas</b><b class="color-primary float-right">$6.00</b></h5>
                                                <p class="pr-70">Proin dictum viverra varius. Etiam vulputate libero dui, at pretium elit elementum quis. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->
                </div><!-- row -->
        </div><!-- container -->
</section><section class="story-area bg-seller color-white pos-relative">
        <div class="pos-bottom triangle-up"></div>
        <div class="pos-top triangle-bottom"></div>
        <div class="container">
                <h4 class="font-30 font-sm-20  center-text mb-25">Add a fresh <b>Salad</b> to your order</h4>
        </div><!-- container -->
</section><section>
        <div class="container">
                <div class="heading mb-sm-10"><h3>Choose from Pasta</h3></div>
                <div class="row">
                        <div class="col-md-12 col-lg-6">
                                <div class="sided-220x responsive mb-30 left-text center-sm-text">
                                        <div class="s-left mlr-sm-auto"><img src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/pasta-1-300x300.png" alt="Menu Image"></div>
                                        <div class="s-right">
                                                <h5>Pizza Margherita</h5>
                                                <h4 class="mtb-10"><b class="color-primary">$12.00</b></h4>
                                                <p>Maecenas fermentum tortor id fringilla molestie. In hac habitasse platea dictumst. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- col-md-6 -->

                        <div class="col-md-12 col-lg-6">
                                <div class="sided-220x responsive mb-30 left-text center-sm-text">
                                        <div class="s-left mlr-sm-auto"><img src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/pasta-2-300x300.png" alt="Menu Image"></div>
                                        <div class="s-right">
                                                <h5>Pizza Margherita</h5>
                                                <h4 class="mtb-10"><b class="color-primary">$12.00</b></h4>
                                                <p>Maecenas fermentum tortor id fringilla molestie. In hac habitasse platea dictumst. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!--col-md-6 -->
                </div><!-- row-->

                <div class="brder-t-light mt-sm-10 mb-60 mb-sm-40"></div>

                <div class="row">
                        <div class="col-md-6">
                                <div class="sided-90x mb-30">
                                        <div class="s-left"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-5-120x120.jpg" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h5 class="mb-10"><b>Pizza Margherita</b><b class="color-primary float-right">$12.00</b></h5>
                                                <p class="pr-70">Maecenas fermentum tortor id fringilla molestie. In hac habitasse platea dictumst. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->

                        <div class="col-md-6">
                                <div class="sided-90x mb-30 ">
                                        <div class="s-left"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-6-120x120.jpg" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h5 class="mb-10"><b>Italian pasta</b><b class="color-primary float-right">$20.00</b></h5>
                                                <p class="pr-70">Proin dictum viverra varius. Etiam vulputate libero dui, at pretium elit elementum quis. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->

                        <div class="col-md-6">
                                <div class="sided-90x mb-30">
                                        <div class="s-left"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-7-120x120.jpg" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h5 class="mb-10"><b>Pizza Prosciuto</b><b class="color-primary float-right">$12.00</b></h5>
                                                <p class="pr-70">Maecenas fermentum tortor id fringilla  molestie. In hac habitasse platea dictumst. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->

                        <div class="col-md-6">
                                <div class="sided-90x mb-30 ">
                                        <div class="s-left"><img class="br-3" src="<?php echo("http://$_SERVER[HTTP_HOST]"); ?>/wordpress/wp-content/themes/zippedTheme-1646243305971/images/menu-8-120x120.jpg" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h5 class="mb-10"><b>Broschettas</b><b class="color-primary float-right">$6.00</b></h5>
                                                <p class="pr-70">Proin dictum viverra varius. Etiam vulputate libero dui, at pretium elit elementum quis. </p>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->
                </div><!-- row -->
        </div><!-- container -->
</section>
              